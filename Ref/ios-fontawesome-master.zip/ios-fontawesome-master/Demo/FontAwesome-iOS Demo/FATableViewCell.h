//
//  FATableViewCell.h
//  FontAwesome-iOS Demo
//
//  Created by Rune Madsen on 2013-01-09.
//  Copyright (c) 2013 Rune Madsen. All rights reserved.
//  runmad.com
//

#import <UIKit/UIKit.h>

@interface FATableViewCell : UITableViewCell

@end
