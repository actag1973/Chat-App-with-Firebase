Firechat-iOS
============

Firechat is a simple chat/messaging app that uses the Firebase iOS SDK. Customize the views to easily
add messaging to your apps!

* By default, new messages are on top. You can reverse the messages by setting `newMessagesOnTop = NO` in the `viewDidLoad:` method of `ViewController`.

License
-------
[MIT](http://firebase.mit-license.org)
